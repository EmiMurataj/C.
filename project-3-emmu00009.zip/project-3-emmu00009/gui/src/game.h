#pragma once

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

#include "common.h"

exit_way playGame(char *filename, bool quantum, char **argv);